#ifndef CMARK_API_TEST_CPLUSPLUS_H
#define CMARK_API_TEST_CPLUSPLUS_H

#include "harness.h"

#ifdef __cplusplus
extern "C" {
#endif

void test_cplusplus(test_batch_runner *runner);

#ifdef __cplusplus
}
#endif

#endif
