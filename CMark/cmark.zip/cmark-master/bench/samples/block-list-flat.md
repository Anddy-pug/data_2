 - tidy
 - bullet
 - list


 - loose

 - bullet

 - list


 0. ordered
 1. list
 2. example


 -
 -
 -
 -


 1.
 2.
 3.


 -  an example
of a list item
       with a continuation

    this part is inside the list

   this part is just a paragraph  


 1. test
 -  test
 1. test
 -  test


111111111111111111111111111111111111111111. is this a valid bullet?

 - _________________________

 - this
 - is

   a

   long
 - loose
 - list

 - with
 - some

   tidy

 - list
 - items
 - in

 - between
 - _________________________
